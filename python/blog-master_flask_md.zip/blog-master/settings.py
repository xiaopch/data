#!/usr/bin/python
# -*- coding:utf-8 -*-

"""Documentation"""

INDEX_DAT = "./static/out/index.dat"

if __name__ == "__main__":
    pass
