#!/usr/bin/python
#-*- coding: UTF-8 -*-
from __future__ import unicode_literals

from flask import Flask, render_template, redirect, url_for, flash
from flask_bootstrap import Bootstrap

from flask import session, request,make_response,send_from_directory
import os
from forms import TodoListForm
from ext import db
from models import TodoList
import platform

SECRET_KEY = 'xp'
app = Flask(__name__)
bootstrap = Bootstrap(app)
##db = SQLAlchemy()
File_Folder='' #raspberry-debian linux
##File_Folder='download' #winddows

app.secret_key = SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = '' #'sqlite:///./db.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
#downlaod dir
if platform.system() == 'Windows':
    File_Folder='download' #raspberry-debian linux
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./db.db'
if platform.system() == 'Linux':
    File_Folder='/root/todolist/download' #raspberry-debian linux
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////root/todolist/db.db' #'sqlite:///./db.db'
        
db.init_app(app)

def check_login():
    
    if '_login' in session:
        if session['_login'] == True:
            return True
    if request.method == 'GET':
        get_params = request.args.to_dict()
        if 't' in get_params.keys():
            t = str(get_params['t']).split('.')
            if len(t) < 2:
                return False
            
            
            session['uid'] = t[1]#get_params['uid']
            token = t[0]
            if token == SECRET_KEY:
                session['_login'] = True
                return True
        else:
            session['_login'] = False
        
    return False

def login():
##    flash('You have add a new todo list')
    return '<h1>not login</h1>'
def post_data(form):
##    form = TodoListForm()
    if form.validate_on_submit():
        content=form.content.data.replace('\n','<p>')#.replace(" ", "&nbsp;")
        todolist = TodoList(session['uid'], content, form.status.data)
        db.session.add(todolist)
        db.session.commit()
        flash('You have add a new todo list')
    else:
        flash(form.errors)
    
    
@app.route('/', methods=['GET', 'POST'])
def show_todo_list_recent():
##    if request.method == 'GET':
##        return str(request.args.to_dict()['uid'])
    
    if not check_login():return login()
    form = TodoListForm()
    if request.method == 'GET':
##        todolists = TodoList.query.all()
##        todolists = TodoList.query.filter_by(status=0).all()
##        todolists = TodoList.query.filter_by(status=1).all()
        todolists = TodoList.query.filter_by(user_id=session['uid']).order_by(TodoList.id.desc()).limit(30).all()
        return render_template('index.html', todolists=todolists, form=form)
    else:
        post_data(form) 
    return redirect(url_for('show_todo_list_recent'))
@app.route('/all', methods=['GET', 'POST'])
def show_todo_list_all():
    if not check_login():return login()
    form = TodoListForm()
    if request.method == 'GET':
##        todolists = TodoList.query.all()
##        todolists = TodoList.query.filter_by(status=0).all()
##        todolists = TodoList.query.filter_by(status=1).all()
        todolists = TodoList.query.filter_by(user_id=session['uid']).order_by(TodoList.id.desc()).limit(100).all()
        return render_template('index.html', todolists=todolists, form=form)
    else:
        post_data(form)
    return redirect(url_for('show_todo_list_recent'))
@app.route('/undo', methods=['GET', 'POST'])
def show_todo_list_undo():
    if not check_login():return login()
    form = TodoListForm()
    if request.method == 'GET':
##        todolists = TodoList.query.all()
        todolists = TodoList.query.filter_by(user_id=session['uid']).filter_by(status=0).order_by(TodoList.id.desc()).limit(30).all()
##        todolists = TodoList.query.filter_by(status=1).all()
##        todolists = TodoList.query.order_by(TodoList.id.desc()).all()
        return render_template('index.html', todolists=todolists, form=form)
    else:
        post_data(form)
    return redirect(url_for('show_todo_list_recent'))

@app.route('/delete/<int:id>')
def delete_todo_list(id):
     if not check_login():return login()
     todolist = TodoList.query.filter_by(id=id).first_or_404()
     db.session.delete(todolist)
     db.session.commit()
     flash('You have delete a todo list')
     return redirect(url_for('show_todo_list_recent'))


@app.route('/change/<int:id>', methods=['GET', 'POST'])
def change_todo_list(id):
    if not check_login():return login()
    if request.method == 'GET':
        todolist = TodoList.query.filter_by(id=id).first_or_404()
        form = TodoListForm()
        form.content.data = todolist.content
        form.status.data = str(todolist.status)
        return render_template('modify.html', form=form)
    else:
        form = TodoListForm()
        if form.validate_on_submit():
            todolist = TodoList.query.filter_by(id=id).first_or_404()
            todolist.content = form.content.data
            todolist.status = form.status.data
            db.session.commit()
            flash('You have modify a todolist')
        else:
            flash(form.errors)
        return redirect(url_for('show_todo_list_recent'))
##def gci(filepath,file_urls):
##  file_urls=[]
#遍历filepath下所有文件，包括子目录
##  files = os.listdir(filepath)
##  for fi in files:
##    fi_d = os.path.join(filepath,fi)            
##    if os.path.isdir(fi_d):
##      gci(fi_d,file_urls)                  
##    else:
##      file_urls.append(fi_d)

@app.route("/l", methods=['GET'])
def list_files():
    if not check_login():return login()
    if not os.path.exists(File_Folder):
        os.makedirs(File_Folder)
    html='<h1>File Download</h1>'
##    file_urls=[]
##    gci(File_Folder,file_urls)
##    for f in file_urls:
####        print f
##        html = html + '<h1><a href=/d/'+f+'>'+f+'</a></h1>'

##    for root,dirs,fs in os.walk(File_Folder):
##        for f in fs:
##            print os.path.join(root,f)
##            html = html + '<h1><a href=/d/'+os.path.join(root,f)+'>'+os.path.join(root,f)+'</a></h1>'
    files = os.listdir(File_Folder)
    for f in files:
        html = html + '<h1><a href=/d/'+f+'>'+f+'</a></h1>'

    return html

@app.route("/d/<filename>", methods=['GET'])
def download_file(filename):
    if not check_login():return login()
    # 需要知道2个参数, 第1个参数是本地目录的path, 第2个参数是文件名(带扩展名)
    directory =  File_Folder
##    return directory
    response = make_response(send_from_directory(directory, filename, as_attachment=True))
    response.headers["Content-Disposition"] = "attachment; filename={}".format(filename.encode().decode('latin-1'))
    return response
    
if __name__ == '__main__':
  

##    print platform.system()
    app.run(host='0.0.0.0', port=88, debug=True)
