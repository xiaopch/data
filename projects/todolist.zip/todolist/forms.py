#!/usr/bin/python
#-*- coding: UTF-8 -*-
from __future__ import unicode_literals
from flask_wtf import FlaskForm
from wtforms import RadioField, SubmitField, StringField, PasswordField,TextAreaField
from wtforms.validators import DataRequired, Length

class TodoListForm(FlaskForm):
    content = TextAreaField('内容', validators=[DataRequired(), Length(3, 10000)])
    status = RadioField('是否完成', validators=[DataRequired()],   default='0', choices=[("1", '是'),("0",'否')])
    submit = SubmitField('提交')


class LoginForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired(), Length(1, 24)])
    password = PasswordField('密码', validators=[DataRequired(), Length(1, 24)])
    submit = SubmitField('登录')
