# -*- coding: cp936 -*-
from tornado.wsgi import WSGIContainer  
from tornado.httpserver import HTTPServer  
from tornado.ioloop import IOLoop  
#import flask project 
from main import app  
  
http_server = HTTPServer(WSGIContainer(app))  
http_server.listen(90)##flask port
IOLoop.instance().start()  
  
#multi process in linux 
# http_server = HTTPServer(WSGIContainer(app))  
# http_server.bind(8888)  
# http_server.start(0)  
# IOLoop.instance().start()  
