#!/usr/bin/python
#-*- coding: UTF-8 -*-
import time
from datetime import datetime,date

from flask_login import UserMixin
from sqlalchemy import  DateTime#Table, Column, Integer, Numeric, String, ForeignKey,
from ext import db

class TodoList(db.Model):
    __tablename__ = 'todolist'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    content = db.Column(db.String(1024), nullable=False)
    status = db.Column(db.Integer, nullable=False)
    create_time = db.Column(DateTime(), default=datetime.now,nullable=False)
##    create_time = db.Column(DateTime(), onupdate=datetime.now, default=datetime.now,nullable=False)
    

    def __init__(self, user_id, content, status):
        self.user_id = user_id
        self.content = content
        self.status = status
##        self.create_time = time.time()


class User(UserMixin, db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(24), nullable=False)
    password = db.Column(db.String(24), nullable=False)

    def __init__(self, username, password):
        self.username = username
        self.password = password
