## 简单个人日记blog系统说明

### 系统说明

* 本系统使用Python的flask框架搭建。
* 使用tornado框架调用flask。
* 前端部分使用bootstrap。


### 运行说明
* 通过终端进入项目文件夹。
* 在终端中执行`python app.py`命令即可运行本地开发服务器。
* 在浏览器里访问[http://127.0.0.1:90/?t=xp.1](http://127.0.0.1:90/?t=xp.1)即可查看该网站。
* url中xp为main.py文件里设的密码，可以修改;1为用户id，取整数;* .为分隔符。
* download文件夹linux需要设置路径，windows不需要。

修改源自：https://github.com/lalor/

